package com.pm.test.entity;

import java.util.List;

import com.pm.test.model.Product;
import com.pm.test.model.SubCategory;

//@Entity
public class CategoryEntity {
	
	String name;
	List<ProductEntity> products;
	List<SubCategoryEntity> subCategories;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<ProductEntity> getProducts() {
		return products;
	}
	public void setProducts(List<ProductEntity> products) {
		this.products = products;
	}
	public List<SubCategoryEntity> getSubCategories() {
		return subCategories;
	}
	public void setSubCategories(List<SubCategoryEntity> subCategories) {
		this.subCategories = subCategories;
	}
	
	

}
