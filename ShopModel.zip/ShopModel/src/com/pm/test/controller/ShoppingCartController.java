package com.pm.test.controller;

import java.util.ArrayList;

import com.pm.test.model.Category;
import com.pm.test.model.Product;
import com.pm.test.model.User;
import com.pm.test.service.CategoryService;
import com.pm.test.service.ProductService;

//@RequestMapping(value = "/customer")
public class ShoppingCartController {
	
	ProductService prodService;
	
	CategoryService catService;

	//@RequestMapping(value = "/addProduct", method = RequestMethod.GET)
	//@ResponseBody
	public void addToCart() {
		Product p = new Product();
		prodService.addProductToCart(p);
		
	}
	
	//@RequestMapping(value = "/removeProduct", method = RequestMethod.GET)
	//@ResponseBody
	public void removeFromCart() {
		Product p = new Product();
		prodService.removeProductToCart(p);
	}
	
	
	//@RequestMapping(value = "/showCart", method = RequestMethod.GET)
	//@ResponseBody
	public void displayCart() {
		User user = new User();
		prodService.getCartDetailsofUser(user);
		
	}
	
	
	//@RequestMapping(value = "/purchaseCart", method = RequestMethod.GET)
	//@ResponseBody
	public void purchaseCart() {
		ArrayList<Product> prodList = new ArrayList<Product>();
		User user = new User();
		prodService.buyProducts(prodList, user);
	}
	
	//@RequestMapping(value = "/showCategories", method = RequestMethod.GET)
	//@ResponseBody
	public void getCategoryList() {
		ArrayList<Category> catList = catService.getCategoryList();
	}
	
	
	//@RequestMapping(value = "/createProduct", method = RequestMethod.GET)
	//@ResponseBody
	public void createProduct() {
		Product p = new Product();
		Category cat = new Category();
		catService.createProduct(p, cat);
	}
	
	

}
