package com.pm.test.util;

import java.util.List;

import com.pm.test.model.Product;
import com.pm.test.model.Seller;
import com.pm.test.model.User;

public class NotificationUtil {
	
	public void sendConfirmationEmail(List<Product> products, User user) {
		//generate email when the user purchases any product
	}
	
	
	public void sendProductPriceChangeUpdateToUser(Product product, User user) {
		//send updated product price via mail through a batch job whenever the price gets updated
	}
	
	public void sendOutOfStockUpdateToSeller(String productName, Seller seller) {
		//send out of stock update to the seller via mail through a batch job whenever certain product gets over
	}
	

}
