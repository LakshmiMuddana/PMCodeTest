package com.pm.test.model;

public class Address {
	
	String houseNo;
	String addrLane1;
	String addrLane2;
	String city;
	String state;
	String country;
	long postal;
	long phone1;
	long phone2;
	
	
	public String getHouseNo() {
		return houseNo;
	}
	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}
	public String getAddrLane1() {
		return addrLane1;
	}
	public void setAddrLane1(String addrLane1) {
		this.addrLane1 = addrLane1;
	}
	public String getAddrLane2() {
		return addrLane2;
	}
	public void setAddrLane2(String addrLane2) {
		this.addrLane2 = addrLane2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public long getPostal() {
		return postal;
	}
	public void setPostal(long postal) {
		this.postal = postal;
	}
	public long getPhone1() {
		return phone1;
	}
	public void setPhone1(long phone1) {
		this.phone1 = phone1;
	}
	public long getPhone2() {
		return phone2;
	}
	public void setPhone2(long phone2) {
		this.phone2 = phone2;
	}
	
}
