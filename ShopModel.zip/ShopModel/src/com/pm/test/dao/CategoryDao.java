package com.pm.test.dao;

import java.util.ArrayList;

import com.pm.test.entity.CategoryEntity;


public class CategoryDao {

	public ArrayList<CategoryEntity> getAllCategories() {
		// make a db call to get the list of categories
		return new ArrayList();
	}

}
