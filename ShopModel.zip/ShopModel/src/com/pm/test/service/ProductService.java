package com.pm.test.service;

import java.util.ArrayList;

import com.pm.test.model.Product;
import com.pm.test.model.User;
import com.pm.test.util.NotificationUtil;

public class ProductService {
	
	NotificationUtil notifyUtil;

	public void addProductToCart(Product p) {
		// TODO Auto-generated method stub
		
	}

	public void removeProductToCart(Product p) {
		// TODO Auto-generated method stub
		
	}

	public void getCartDetailsofUser(User user) {
		// TODO Auto-generated method stub
		
	}

	public void buyProducts(ArrayList<Product> prodList, User user) {
		// TODO Auto-generated method stub
		for(Product prod:prodList) {
			if(prod.getType().equalsIgnoreCase("digital")) {
				notifyUtil.sendConfirmationEmail(prodList, user);
			} else if(prod.getType().equalsIgnoreCase("normal")) {
				//send product by post
			}
		}
	}

}
