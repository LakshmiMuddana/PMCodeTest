package com.pm.test.service;

import java.util.ArrayList;

import com.pm.test.dao.CategoryDao;
import com.pm.test.entity.CategoryEntity;
import com.pm.test.model.Category;
import com.pm.test.model.Product;

public class CategoryService {
	
	CategoryDao categoryDao;

	public ArrayList<Category> getCategoryList() {
		
		ArrayList<Category> catList = new ArrayList<Category>();
		ArrayList<CategoryEntity> catListDB = categoryDao.getAllCategories();
		for(CategoryEntity ce: catListDB) {
			Category cat = new Category();
			catList.add(cat);
		}
		return catList;
	}

	public void createProduct(Product p, Category cat) {
		// create a product and add it to specific category
		
	}

}
