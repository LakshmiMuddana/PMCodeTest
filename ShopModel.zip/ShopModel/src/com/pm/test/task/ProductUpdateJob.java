package com.pm.test.task;

import com.pm.test.model.Product;
import com.pm.test.model.Seller;
import com.pm.test.model.User;
import com.pm.test.util.NotificationUtil;

public class ProductUpdateJob {
	
	NotificationUtil notifyUtil;
	
	public void productPriceUpdateTask(Product prod, User user) {
		notifyUtil.sendProductPriceChangeUpdateToUser(prod, user);
	}
	
	public void productOutofStockTask(String prodName, Seller seller) {
		notifyUtil.sendOutOfStockUpdateToSeller(prodName, seller);
	}

}
